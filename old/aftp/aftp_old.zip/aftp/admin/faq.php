<?
include "config.inc.php";
include_once(PATH_API.'/faq.class.php');
$obj= new faq();
$obj->action();
debug_echo();
?>
