<?php

/**
 * The 'deleteA' command.
 * Permanently deletes an already-reserved job.
 *
 * @author Paul Annesley
 * @package Pheanstalk
 * @licence http://www.opensource.org/licenses/mit-license.php
 */
class Pheanstalk_Command_DeleteACommand extends Pheanstalk_Command_AbstractCommand implements Pheanstalk_ResponseParser {

    private $_id;

    /**
     * @param object $job Pheanstalk_Job
     */
    public function __construct($id) {
	$this->_id = $id;
    }

    /* (non-phpdoc)
     * @see Pheanstalk_Command::getCommandLine()
     */

    public function getCommandLine() {
	return 'delete ' . $this->_id;
    }

    /* (non-phpdoc)
     * @see Pheanstalk_ResponseParser::parseRespose()
     */

    public function parseResponse($responseLine, $responseData) {
	if ($responseLine == Pheanstalk_Response::RESPONSE_NOT_FOUND) {
	    return false;
	}
	return $this->_createResponse($responseLine);
    }

}
