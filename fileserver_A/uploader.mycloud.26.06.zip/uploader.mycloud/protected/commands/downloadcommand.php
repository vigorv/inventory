<?php

class DownloadCommand extends CConsoleCommand {

    public function actionSyncUnt($args) {
	$tasklist = CBeanstalk::model()->tasklist();
	//$tasklist = new Pheanstalk;
	while (True) {
	    echo "Wait for job ";
	    $job = $tasklist->reserveFromTube('download_unt');
	    if ($job) {
		$job_id = $job->getId();
		$job_data = json_decode($job->getData());
		echo "Receive one ";

		// DownloadServer Copied file to self
		if (!isset($job_data->sync_only)) {
		    echo "Trying to copy ";
		    $dest = exec('mktemp -p /mnt/userdata u_' . $job_data->user_id . '_XXXXXXXXXXX');
		    $savename = pathinfo($dest, PATHINFO_BASENAME);
		    shell_exec('rsync ' . '/mnt/remote/' . $job_data->ip . '/' . $job_data->fname . '  ' . $dest);
		    shell_exec('chown nobody:nobody '.$dest);
		    shell_exec('chmod +r '.$dest);
		    //shell_exec("scp $job_data->ip:/var/tmp/uploads/$job_data->fname /mnt/userdata/$job_data->fname");
		    // add MetaData to server
		    if (file_exists($dest)) {
			$fsize = filesize($dest);
			if ($fsize == $job_data->fsize) {
			    $job_data->sync_only = 1;
			}
		    }
		} else {
		    $savename = $job_data->savename;
		}
		if ((isset($job_data->sync_only)) AND ($job_data->sync_only == 1)) {
		    $tasklist->delete($job);
		    echo "Sync to server";
		    
		    $result=CServerSync::CreateFileLocation($job_data->variant_id, $job_data->fsize, $savename);
		    //$result = CSssl::model()->Data('/serversync/download', $job_data->user_id, array('fid' => $job_data->fid, 'save' => $savename, 'fsize' => $fsize));
		    //if ok delete task
		    
		    if ((!$result) || (isset($result['error']))) {
			echo "not ok";
			$job_data->savename = $savename;
			$tasklist->putInTube('download_unt', json_encode($job_data), 100, 10, 20); // else create new sync task
		    }
		} else {

		    $tasklist->release($job);
		}
	    }
	}
    }

    public function actionSyncT($args) {
	$tasklist = CBeanstalk::model()->tasklist();
	//$tasklist = new Pheanstalk;
	while (True) {
	    echo "Wait for job ";
	    $job = $tasklist->reserveFromTube('download_t');
	    if ($job) {
		$job_id = $job->getId();
		$job_data = json_decode($job->getData());
		echo "Receive one ";
		$path = '';
		// DownloadServer Copied file to self
		if (!isset($job_data->sync_only)) {
		    echo "Trying to copy ";
		    if (isset($job_data->path))
			$path = $job_data->path;
		    $src = '/mnt/remote/' . $job_data->ip . '/' . $job_data->fname;
		    $res = exec('mktemp -p /mnt/usertyped t_' . $job_data->user_id . '_XXXXXXXXXXX');
		    echo $src . ' ';
		    echo $res;
		    shell_exec('rsync ' . $src . ' ' . $res);
		    shell_exec('chown nobody:nobody '.$res);
		    shell_exec('chmod +r '.$res);
		    $savename = pathinfo($res, PATHINFO_BASENAME);
		    //shell_exec("scp $job_data->ip:/var/tmp/uploads/$job_data->fname /mnt/userdata/$job_data->fname");
		} else
		    $savename = $job_data->savename;



		if (file_exists($res)) {
		    $fsize = filesize($res);
		    if ($fsize <> $job_data->fsize) {
			echo "size is bad ".$fsize.'<> '.$job_data->fsize.PHP_EOL;
			unlink($res);
			$tasklist->release($job, 50, 30);
			continue;
		    }
		} else {
		    echo "not exists $res ";
		    $tasklist->release($job, 50, 30);
		    continue;
		}

		// add MetaData to server
		echo "Sync to server";
		$result = CSssl::model()->Data('/serversync/typify', $job_data->user_id, array(
		    'file_id' => $job_data->fid,
		    'save' => $savename,
		    'task_id' => $job_data->task_id,
		    'fsize' => $fsize,
			));
		//if ok delete task
		echo "Deleting task".PHP_EOL;
		$tasklist->delete($job);
		#if (!strstr($result, "OK")) {
		   # $job_data->sync_only = 1;
		    #$job_data->savename = $savename;
		    #$tasklist->putInTube('download_t', json_encode($job_data), 50, 10, 20); // else create new sync task
		#}
	    }
	}
    }

}