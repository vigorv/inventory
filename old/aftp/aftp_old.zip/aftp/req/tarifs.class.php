<?
debug("%1%���������� req/tarifs.class.php");

include_once PATH_REPOSIT."/template.class.php";
class tarifs extends template
{
    function tarifs()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='������';
    	 $this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 		$var=array();
	 		$var["name"]="name";$var["string"]="��������";
	 	$vars[$var["name"]]=$var;
	 		
	 	    $var=array();
	 		$var["name"]="size";$var["string"]="��������� �����";
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="cost";$var["string"]="����";
	 	$vars[$var["name"]]=$var;
        $configs["table_name"]='tarifs';

	 	$this->init($vars,$configs);
    }
}
?>
