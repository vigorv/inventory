<?
debug("%1%���������� req/proftpd_users.class.php");

include_once PATH_REPOSIT."/template.class.php";
class proftpd_users extends template
{
    function proftpd_users()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='proftpd users';
    	 //$this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();
        $configs["get_arrays"]['proftpd.groups']=array("name");

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="login";$var["string"]="������������";
	 	$vars[$var["name"]]=$var;

	 		$var=array();
	 		$var["name"]="passwd";$var["string"]="������";
	 		$var["is_show"]=0;
	 	$vars[$var["name"]]=$var;
	 		
	 		
            $var=array();
	 		$var["name"]="gid";$var["string"]="������";
            $var["edit"]["type"]="list";
            $var["edit"]["value_list"]='proftpd.groups';
            $var["show"]["type"]='proftpd.groups';
            $vars[$var["name"]]=$var;

 	        $var=array();
	 		$var["name"]="homedir";$var["string"]="���.";
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="count";$var["string"]="������";
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="accessed";$var["string"]="����1";
	 	$vars[$var["name"]]=$var;
	 	
	 	    $var=array();
	 		$var["name"]="modified";$var["string"]="����2";
	 	$vars[$var["name"]]=$var;
	 	
	 	$this->PARAMS["showparams"]['childs']=array
        (
        'quota1'=>array(
        'icon'=>array('Descr','�����1')
        ,'link'=>'proftpd_users_quotatallies.php?p=%id%'
        )
        ,'quota2'=>array(
        'icon'=>array('Descr','�����2')
        ,'link'=>'proftpd_users_quotalimits.php?p=%id%'
        )

        );

        $configs["table_name"]='proftpd.users';

	 	$this->init($vars,$configs);
    }

}
?>
