<?
include "config.inc.php";
include_once(PATH_API.'/proftpd_users_quotalimits.class.php');
$obj= new proftpd_users_quotalimits();
$obj->action();
debug_echo();
?>
