<?php
$dir = '/home/admin/test/filexchange';

chmod($dir, 0777);
chmodding($dir);
function chmodding($dir){
    if ( $dh = opendir($dir)) {
        while (($file = readdir($dh)) !== false){
            if ($file!='..' && $file!='.'){
                echo $dir.'/'.$file.' ';
                if (is_file($dir.'/'.$file)){
                    chmod ($dir.'/'.$file, 0666);
                    echo "Ok (file) \n";
                }
                elseif (is_dir($dir.'/'.$file)) {
                    chmod ($dir.'/'.$file, 0777);
                    echo "Ok (dir) \n";
                    chmodding($dir.'/'.$file);
                }
                else echo "ERR (?) \n";
            }
        }
        closedir($dh);
    }
    else echo "dont open dir '{$dir}' \n";
}
?>
