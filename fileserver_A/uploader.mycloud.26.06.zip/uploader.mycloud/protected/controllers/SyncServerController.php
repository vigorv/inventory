<?php

class SyncServerController extends Controller {
    
    public function beforeAction($action) {
        parent::beforeAction($action);
        $this->layout='ajax';
    }
    
    public function actionInitConvert(){
        $filename='';
        $path='';
        $return_id;
    }
    
    public function actionConvertStatus(){
    }
    
    
    public function actionIndex(){
        $this->render('index');
    }
    
    
}