<?
include "config.inc.php";
include_once(PATH_API.'/proftpd_users_quotatallies.class.php');
$obj= new proftpd_users_quotatallies();
$obj->action();
debug_echo();
?>
