<?php

class FilesController extends Controller
{

    public function beforeAction($action)
    {
        parent::beforeAction($action);
        return true;
        /*
        if (isset($_GET['gdata']))
            $_GET = unserialize($_GET['gdata']);

        if (isset($_SESSION['user_id']))
            return true;

        if (isset($_GET['kpt'])) {
            $kpt = filter_var($_GET['kpt'], FILTER_SANITIZE_STRING);
            if (strlen($kpt) <> 32)
                die(json_encode(array('error' => 'bad hash_0')));
            if (isset($_GET['user_id'])) {
                $user_id = (int)$_GET['user_id'];
                if ($user_id < 1)
                    die(json_encode(array('error' => "Bad User")));
            } else
                die(json_encode(array('error' => 'unknown user')));
        } else {
            die(json_encode(array('error' => 'Access Denied')));
        }
        $user_data = CSssl::model()->Data('/serversync/userdata', $user_id);
        $user_data = @unserialize($user_data);
        if ($user_data) {
            if (!isset($user_data['error'])) {
                $kpt2 = md5($user_id . $user_data['sid'] . "I am robot");
                if ($kpt == $kpt2) {
                    $_SESSION['user_id'] = $user_id;
                    return true;
                } else
                    die(json_encode(array('error' => 'You are unknown')));
            } else
                die(json_encode(array('error' => 'Unable to connect')));
        } else
            die(json_encode(array('error' => 'Can not sync data')));
        return true;
        */
    }


    public function actionUploadForm()
    {
        $hash = md5(rand(1, 1000));
        $this->layout = 'ajax';
        $this->renderPartial('upload', array('hash' => $hash));
        exit;
    }

    public function actionDownload()
    {
        $fid = (int)$_GET['fid'];
        $user_ip = getenv('REMOTE_ADDR');
        $file_info = CSssl::model()->Data('/serversync/filedata', $_SESSION['user_id'], array('fid' => $fid, 'stype' => 1, 'user_ip' => $user_ip));
        $filedata = @unserialize($file_info);
        if (!$filedata)
            die(json_encode(array('error' => 'Can not sync to server')));

        if (isset($filedata['error']))
            die(json_encode(array('error' => $filedata['error'])));

        if (!isset($filedata['title']))
            die(json_encode(array('error' => 'File not exists or unknown')));

        if (!isset($filedata['filedata'])) {
            die(json_encode(array('error' => 'File in progress.')));
        }

        if (isset($filedata['server'])) {
            $server = $filedata['server'];
            $this->redirect($server);
        }
        $fileloc = $filedata['filedata'][0];
        $base_path = '/mnt/userdata/';
        $filename = $base_path . $fileloc['name'];
        if (!file_exists($filename)) {
            echo "Not found " . $filename;
            //header("HTTP/1.0 404 Not Found");
            exit;
        }

        Yii::app()->request->xSendFile($filename, array(
            'saveName' => $filedata['title'],
            'xHeader' => 'X-Accel-Redirect'));

/// Code stopes here !!!!  <<<<<<<<<<<<<<<<<<<-------------------------------
        $fsize = filesize($filename);
        $ftime = date("D, d M Y H:i:s T", filemtime($filename));
        $fd = @fopen($filename, "rb");
        if (!$fd) {
            header("HTTP/1.0 403 Forbidden");
            exit;
        }
// Если запрашивающий агент поддерживает докачку
        $range = false;
        if (isset($_SERVER["HTTP_RANGE"])) {
            $range = $_SERVER["HTTP_RANGE"];
            $range = str_replace("bytes=", "", $range);
            $range = str_replace("-", "", $range);
            if ($range) {
                fseek($fd, $range);
            }
        }

        if ($range) {
            header("HTTP/1.1 206 Partial Content");
        } else {
            header("HTTP/1.1 200 OK");
        }
        header("Content-Disposition: attachment; filename=\"" . $filedata['title'] . "\"");
        header("Last-Modified: $ftime");
        header("Accept-Ranges: bytes");
        header("Content-Length: " . ($fsize - $range));
        header("Content-Range: bytes $range-" . ($fsize - 1) . "/" . $fsize);
        header("Content-type: application/octet-stream");
        echo fread($fd, filesize($filename));
        fclose($fd);
        exit;
    }

    static private function pathMaker($uid, $fname)
    {
        $save_folder = Yii::app()->params['save_folder'];
        $usr_prefix = md5('data' . $uid . 'u');
        $dpath = $usr_prefix . '/';
        if (!is_dir($save_folder . $dpath))
            return $dpath;
        $dest = $save_folder . $dpath . $fname;

        while (file_exists($dest)) {
            $td = md5(time());
            $dpath = $usr_prefix . '/' . $td . '/';
            $dest = $save_folder . $dpath . $fname;
        }
        return $dpath;
    }

    public function actionUploads()
    {
   //   var_dump($_POST);
 /*
 array(6) {
  ["key"]=>
    string(40) "303950c44e9fc689de5ea97244153be97cf2c348"
  ["userid"]=>
    string(1) "2"
  ["Filedata_name"]=>
    string(18) "Vox_0.3_beta_1.zip"
  ["Filedata_path"]=>
    string(36) "/mnt/data/mycloud/uploads/0000000007"
  ["Filedata_md5"]=>
    string(32) "4f99a3e6d33ec0b6e2b249dc1740a863"
  ["Filedata_size"]=>
    string(7) "2070317"
        }

 */

        if (isset($_POST['Filedata_name'])
            && isset($_POST['Filedata_path'])
            && isset($_POST['userid'])
            && isset($_POST['key'])
            && ((int)$_POST['userid']>0)
        ) {
            $uid = (int)$_POST['userid'];

            $fname = filter_var($_POST['Filedata_name'], FILTER_SANITIZE_STRING);
            $fileSize = $_POST['Filedata_size'];

            $rm_cmd = "rm " . $_POST['Filedata_path'];
            $src = $_POST['Filedata_path'];
            $fsize = filesize($src);

            if (!($fsize) || !($fsize == $fileSize) || ($fsize == 0)) {
                $result = array('error' => "bad size " . $fsize . ' : ' . $fileInfo['size']);
                exec($rm_cmd);
                echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
                Yii::app()->end();
            }

            $dpath = self::pathMaker($uid, $fname);
            $save_folder = Yii::app()->params['save_folder'];
            $dest = $save_folder . $dpath . $fname;
            $fc_cmd = 'mkdir "' . $save_folder . $dpath . '" && chmod 0777 "' . $save_folder . $dpath . '"';
            $mv_cmd = "mv " . $_POST['Filedata_path'] . " " . $dest;


            $syncData = array();
            $syncData['md5'] = $_POST['Filedata_md5'];
            $syncData['size'] = $_POST['Filedata_size'];
            $syncData['name'] = $fname;
            $syncData['path'] = $dpath;
            $syncData['src'] = $fname;
            $syncData['key'] = filter_var($_POST['key'], FILTER_SANITIZE_STRING);
            $syncData['uid'] = $uid;
            $syncData['server_ip'] = Yii::app()->params['server_ip'];

            Yii::log(CVarDumper::dumpAsString($syncData),'trace','vardump');

            $fdata = base64_encode(serialize($syncData));
            $sdata = sha1($fdata . Yii::app()->params['uploads_skey']);

            $url = Yii::app()->params['service_uri'] . '/serversync/upload?fdata=' . $fdata . '&sdata=' . $sdata;
           // echo $url;

            $data = file_get_contents($url);
            $try = 0;
            while (!$data && $try < 10) {
                $data = file_get_contents($url);
                if ($data) break;
                sleep(1);
                $try++;
            }
            Yii::log(CVarDumper::dumpAsString($data),'trace','vardump');

            if ($data) {
               // echo $data;
                $rdata = unserialize(base64_decode($data));
                //var_dump($rdata);
                Yii::log(CVarDumper::dumpAsString($rdata),'trace','vardump');
                //var_dump($data);
                if (isset($rdata['id'])) {
                    if (!is_dir($save_folder . $dpath))
                        exec($fc_cmd);
                    exec($mv_cmd);
                    $result = array('success' => $rdata['id']);
                    echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
                    Yii::app()->end();
                } else
                    $result = array('error' => 'Sync: '.$rdata['error_msg']);
            } else {
                $result = array('error' => 'Save fail');
            }
            echo htmlspecialchars(json_encode($result), ENT_NOQUOTES);
            exec($rm_cmd);
            exit();

        } else {
            header("HTTP/1.1 400 Bad Request", true, 400); //nginx_cleanup_by_http_code
            exit;
        }


    }

}

?>