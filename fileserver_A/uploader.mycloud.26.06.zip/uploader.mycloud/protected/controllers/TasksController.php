<?php

class TasksController extends Controller {

    public function actionAddtask() {
	$tasklist = CBeanstalk::model()->tasklist();
	if (isset($_GET['data'])) {
	    $data = @unserialize($_GET['data']);
	    if ($data) {
		$queue_id = (int) $data['queue'];
		switch ($queue_id) {
		    case 1 : $tasklist->useTube('converter');
			break;
		    default:
			die('unknow queue');
		}
		$cdata['user_id'] = $data['user_id'];
		$cdata['fpath'] = $data['fpath'];
		$cdata['fname'] = $data['fname'];
		$cdata['fid'] = $data['fid'];
		$cdata['fsize'] = $data['fsize'];
		$cdata['preset'] = $data['preset'];
		$cdata['ip'] = $data['ip'];
		$job_id = $tasklist->put(json_encode($cdata), 50, 0, 36000);
		echo $job_id;
		exit;
	    }else
		echo 0;
	} else
	    echo 0;
	exit;
    }

    public function actionStatus($job_id) {
    $LOG = "/mnt/remote/converter/$job_id/log";
	//echo $LOG;
	$LOG2 = '/tmp/' . $job_id . '_out';
	if (file_exists($LOG)) {
	    $tr = " tr '" . '\r' . "' '" . '\n' . "' < $LOG > $LOG2";
	    shell_exec($tr);

	    $awk = "'BEGIN { FS = " . ' ' . " } ; { print $6}'";
	    #extract percentage of last line
	    $progress = `tail -1 $LOG2 | awk 'BEGIN { FS = " " } ; { print $6}'`;

	    echo json_encode(array('progress' => $progress));
	} else
	    die('file not exists ' . $LOG);
	exit;
    }

    public function actionAbort() {
	$tasklist = CBeanstalk::model()->tasklist();
	//$tasklist = new Pheanstalk;
	if (isset($_GET['data'])) {
	    $data = @unserialize($_GET['data']);
	    if ($data) {
		$queue_id = (int) $data['queue'];
		switch ($queue_id) {
		    case 1 : $tasklist->useTube('convertA');
			break;
		    default:
			die('unknow queue');
		}
		$deleted = @$tasklist->deleteA($data['task_id']);
		if (!$deleted) {
		    $job_stat = $tasklist->statsJobA($data['task_id']);
		    if (!($job_stat <= 0)) {
			$cdata['task_id'] = $data['task_id'];
			$job_id = $tasklist->put(json_encode($cdata), 50, 0, 3600);
			echo 0;
		    } else
			echo 1;
		} else {
		    echo 1;
		}
		exit;
	    } else
		echo "unknown data";
	}
	echo "unknown";
	exit;
    }

}