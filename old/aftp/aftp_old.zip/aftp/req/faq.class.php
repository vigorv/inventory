<?
debug("%1%���������� req/faq.class.php");

include_once PATH_REPOSIT."/template.class.php";
class faq extends template
{
    function faq()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='FAQ';
    	 $this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 		$var=array();
	 		$var["name"]="question";$var["string"]="������";
	 	$vars[$var["name"]]=$var;
	 		
	 	    $var=array();
	 		$var["name"]="answer";$var["string"]="�����";
	 		$var['is_show']=0;
            $var['edit']['type']='text';
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="date";$var["string"]="����";
	 	$vars[$var["name"]]=$var;
        $configs["table_name"]='faq';

	 	$this->init($vars,$configs);
    }

    function action_user()
    {
        global $SETTINGS,$ADMN_USER_ID;
        //
        $id=(isset($_REQUEST['id']))?(int)$_REQUEST['id']:0;
        $this->PARAMS["id"]=$id;
        $p=(isset($_REQUEST['p']))?$_REQUEST['p']:$this->PARAMS['parent'];
        $this->PARAMS['parent']=$p;
        $act=(isset($_REQUEST['act']))?$_REQUEST['act']:'';
        $s=(isset($_REQUEST['s']))?$_REQUEST['s']:0;
        $f=(isset($_REQUEST['f']))?$_REQUEST['f']:0;
        $d=(isset($_REQUEST['d']))?$_REQUEST['d']:0;

        $err_flag=0;
        $this->PARAMS["sort"]=(int)$s;
        $this->PARAMS["direct"]=(int)$d;
        $this->PARAMS["cur_page"]=(int)$f;

        $this->PARAMS["out_url"]=$this->out_url($this->PARAMS["url_link"],$_REQUEST);
        $this->mysql= new mySQL();
        include $SETTINGS["PATH_INC"]."/top.html";
        $this->show();
        include $SETTINGS["PATH_INC"]."/faq.html";
        include $SETTINGS["PATH_INC"]."/bottom.html";
        $this->mysql->sql_close();
    }
    function show()
    {
        $where=' ';
        $addsql="";$sql1="";$LIMIT="";$i=0;

        $sort='date';
        $outs=array('id','date','question','answer');
        $addsql="order by ".$sort;
        if(isset($this->PARAMS["direct"]) &&$this->PARAMS["direct"]==1)$addsql.=" desc ";
        $func_in=implode(", " ,$outs);

        $qf=0;
        if($this->SETTINGS["COUNT_OBJ_ON_PAGE"]>0){
            $StLimit=(int)$this->PARAMS["cur_page"]*$this->SETTINGS["COUNT_OBJ_ON_PAGE"];

            $this->mysql->sql_execute("select ".$func_in." from ".$this->SETTINGS["table"]." ".$where);

            $count=$this->mysql->sql_num_rows();
            if($count>$this->SETTINGS["COUNT_OBJ_ON_PAGE"]){
                $pager=new Pager($count,$this->SETTINGS["COUNT_OBJ_ON_PAGE"],$this->PARAMS["cur_page"],$this->PARAMS["out_url"]);
                $pager->Create($this->SETTINGS['pager_type']);
                $this->PARAMS["pager"]=$pager->Get();
            }
            $LIMIT=" LIMIT ".$StLimit.",".$this->SETTINGS["COUNT_OBJ_ON_PAGE"];
        }
        $res=$this->mysql->sql_execute("select ".$func_in." from ".$this->SETTINGS["table"]." ".$where." ".$addsql.$LIMIT);
        if($this->PARAMS["ERR"])return 0;
        $count=0;
        $outar=array();
        while($out=$this->mysql->sql_fetch_assoc()){
            $count++;
            $curar=array();
                $curar['id']=$out['id'];
                $curar['question']=$out['question'];
                $curar['answer']=$out['answer'];
                $curar['date']=$out['date'];
                
            $curar["num"]=$StLimit+$count;
            $outar[]=$curar;
        }
        $this->PARAMS[$this->SETTINGS["table_prefix"]."show"]=$outar;
        return $this->PARAMS[$this->SETTINGS["table_prefix"]."show"];
    }
}
?>
