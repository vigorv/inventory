<?php

class UploadCommand extends CConsoleCommand {

    public $subject;

    protected function setUp() {
	$this->subject = new Socket_Beanstalk(array(
		    'host' => Yii::app()->params['mycloud']['task_ip'],
		    'port' => '10000'
		));
	if (!$this->subject->connect()) {
	    $message = 'Need a running beanstalk server at Task';
	    return $false;
	}
	return true;
    }

    /*
      CONVERT JOB Data:

      cmd
      real_server_ip
      preset_id
      filename

     */

    public function ActionSync($args) {
	$task = CBeanstalk::model()->subject;
	//$task =  new Pheanstalk;
	while (true) {
	    echo "waiting for task ";
	    $res = @$task->reserveFromTube('upload');
	    echo "processing task ";
	    if ($res) {
		$job_id = @$res->getId();
		$data = @$res->getData();
		if (($data) && ($job_id)) {
		    $job = @json_decode($data);
		    //print_r($job);
		    $fname=base64_encode($job->filename);
		    $result = CSssl::model()->
			    Data('/serversync/upload', $job->user_id, array('filename' => $fname, 'fsize' => $job->fsize, 'save' => $job->savename,
			'pid' => $job->pid));

		    $result = @unserialize($result);

		    if (($result) && (!isset($result['error']))) {
			$task->delete($res);
			echo "sync complete. Create download task";
			
		    } else
			$task->release($job_id, 1, 10);
		}
	    }
	}
    }

}

?>