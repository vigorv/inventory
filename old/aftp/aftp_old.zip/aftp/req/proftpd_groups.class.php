<?
debug("%1%���������� req/proftpd_groups.class.php");

include_once PATH_REPOSIT."/template.class.php";
class proftpd_groups extends template
{
    function proftpd_groups()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='proftpd users';
    	 //$this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();
        $configs["get_arrays"]['proftpd.groups']=array("name");

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="name";$var["string"]="��������";
	 	$vars[$var["name"]]=$var;

	 	     $var=array();
	 		$var["name"]="members";$var["string"]="������������";
	 	$vars[$var["name"]]=$var;

	 	$vars[$var["name"]]=$var;
        $configs["table_name"]='proftpd.groups';

	 	$this->init($vars,$configs);
    }

}
?>
