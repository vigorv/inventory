<?
include "config.inc.php";
include_once(PATH_API.'/index_admn.class.php');
$obj= new index();
//echo transliteratetodir(".comqweretrtytuoi[p]asdsdfhgjjhlk' ");
debug_echo();
?>


