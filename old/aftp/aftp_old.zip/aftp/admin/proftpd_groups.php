<?
include "config.inc.php";
include_once(PATH_API.'/proftpd_groups.class.php');
$obj= new proftpd_groups();
$obj->action();
debug_echo();
?>
