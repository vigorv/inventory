<?
debug("%1%���������� req/proftpd_users_quotatalimits.class.php");

include_once PATH_REPOSIT."/template.class.php";
class proftpd_users_quotalimits extends template
{
    function proftpd_users_quotalimits()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='proftpd';
    	 //$this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();
        $configs["get_arrays"]['proftpd.users']=array("login");
        $this->PARAMS["showparams"]["parent"]=array(
                                                'table'=>'proftpd.users'
                                                ,'name'=>'������������'
                                                ,'column'=>'login'
                                                ,'where'=>'id=%p%'
                                                ,"link"=>'proftpd_users.php?id=%p%&act=show'
                                              );

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="parent";$var["string"]="������������";
            $var["edit"]["type"]="list";
            $var["edit"]["value_list"]='proftpd.users';
            $var["show"]["type"]='proftpd.users';
       $vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="login";$var["string"]="������������";
	 	$vars[$var["name"]]=$var;

	 	     $var=array();
	 		$var["name"]="bytes_in_avail";$var["string"]="���� ��������";
	 	$vars[$var["name"]]=$var;

	 	$vars[$var["name"]]=$var;
        $configs["table_name"]='proftpd.quotalimits';

	 	$this->init($vars,$configs);
    }

}
?>
