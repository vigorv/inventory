<?
include "config.inc.php";
include_once(PATH_API.'/tarifs.class.php');
$obj= new tarifs();
$obj->action();
debug_echo();
?>
