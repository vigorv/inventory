<?php

CBeanstalk::model();

class ConvertCommand extends CConsoleCommand {

	/**
	 * OLD FUNC Do not use
	 * @param type $args 
	 */
	public function ActionConvert($args) {
		$tasklist = CBeanstalk::model()->tasklist();
		while (true) {
			$waiter = true;
			$pid = pcntl_fork();
			if ($pid == -1) {
				die('не получилось');
			} else if ($pid) {
				$children = $pid;
				echo "kid " . $pid . ' ';
				echo "wating";
				while ($waiter) {
					$killer = $tasklist->reserveFromTube('convertA', 15);
					if ($killer) {
						$killer_data = @unserialize($killer->getData());
						$ktask_id = $killer_data['task_id'];
						if ($ktask_id == $job_id) {
							echo "killing signal. Kill all ";
							$tasklist->delete($job);
							shell_exec('kill ' . $pid);
							shell_exec('rm -rf' . $conv_path);
							$tasklist->delete($killer);
							$waiter = false;
						} else
							$tasklist->release($killer, 10, 5);

						while (pcntl_wait($status, WNOHANG OR WUNTRACED) > 0) {
							$waiter = false;
						}
					}
				}
			} else {
				echo "OK i'm start";
				echo 'Wating for job';
				$job = @$tasklist->reserveFromTube('converter', 25);
				if ($job) {

					echo 'Got job ';
					$job_id = $job->getId();

					$job_data = json_decode($job->getData());
					$path = '';
					$conv_cp = '/mnt/remote/' . $job_data->ip . '/' . $path . $job_data->fname;
					echo $conv_cp;
					$conv_path = '/mnt/convert/' . $job_id . '/';
					$conv_src = '/mnt/convert/' . $job_id . '/' . $job_data->fname;
					if (!isset($job_data->step)) {
						echo "Trying to copy ";
						if (isset($job_data->fpath))
							$path = $job_data->fpath;
						shell_exec('mkdir ' . $conv_path);
						shell_exec('rsync ' . $conv_cp . ' ' . $conv_src);
//shell_exec("scp $job_data->ip:/var/tmp/uploads/$job_data->fname /mnt/userdata/$job_data->fname");
					}

					if (file_exists($conv_src)) {
						$fsize = filesize($conv_src);
						if ($fsize <> $job_data->fsize) {
							echo "size is bad";
							$tasklist->release($job, 50, 30);
							continue;
						}
					} else {
						echo "not exists $conv_src ";
						$tasklist->release($job, 50, 30);
						continue;
					}

					$conv_dest = '/mnt/convert/' . $job_id . '/result';
					echo "Convert start";




					shell_exec('/usr/scripts/convert/v/' . $job_data->preset . '.sh ' . $conv_src . ' ' . $conv_dest);
					$tasklist->delete($job);
					if (file_exists($conv_dest)) {
						echo "Converted";
						$size = filesize($conv_dest);
						if ($size > 0) {
							$data = array();
							$data['ip'] = '192.168.201.164';
							$data['user_id'] = $job_data->user_id;
							$data['stype'] = 4;
							$data['fsize'] = $size;
							$data['fname'] = '/' . $job_id . '/result';
							$data['job_id'] = $job_id;
							$tasklist->putInTube('download_t', $data, 50, 0, 2000);
							$tasklist->delete($job);
						} else {
							echo "bad result size";
							$job_data->step = 1;
							$tasklist->putInTube('convert', json_encode($job_data), 50, 10, 2000); // else create new sync task
						}
					} else {
						echo "Convert failed";
						$job_data->step = 1;
						$tasklist->putInTube('convert', json_encode($job_data), 50, 10, 2000); // else create new sync task
					}
					exit(1);
				}
			}
		}
	}

	/*
	 *  Converter
	 */

	public function actionConverter() {
		$tasklist = CBeanstalk::model()->tasklist();
		if (!CThread::$useForks) {
			echo PHP_EOL . "You do not have the minimum system requirements to work in async mode!!!";
			if (!CShell::$hasForkSupport) {
				echo PHP_EOL . "You don't have pcntl or posix extensions installed or either not CLI SAPI environment!";
			}
			if (!CShell::$hasLibevent) {
				echo PHP_EOL . "You don't have libevent extension installed!";
			}
			echo PHP_EOL;
		}

// ----------------------------------------------
		$threads = 2;

		echo PHP_EOL . "Example with pool of threads ($threads) " . PHP_EOL;

		$pool = new CThreadPool('ConvertThreadEvents', $threads);
		$run = true;
		$started = array();


		while ($run) {
			if ($pool->hasWaiting()) {
				$job = $tasklist->reserveFromTube('converter', 25);
				if ($job) {
					if (!$threadId = $pool->run($job)) {
						
					} else
						$started[$threadId] = $job;
				}
			}
			try {
				if ($results = $pool->wait($failed)) {
					foreach ($results as $threadId => $result) {
						var_dump($result);
						$tasklist->deleteA($started[$threadId]->getId());
						unset($started[$threadId]);
						echo 'result: ' . $result . PHP_EOL;
					}
				}
			} catch (Eception $e) {
				echo 'Message: ' . $e->getMessage();
			}
			if ($failed) {
// Error handling here
// processing is not successful if thread dies
// when worked or working timeout exceeded
				foreach ($failed as $threadId) {
					$tasklist->deleteA($started[$threadId]->getId());

					echo 'error: ' . $started[$threadId] . PHP_EOL;
					unset($started[$threadId]);
				}
			}
		}
		$pool->cleanup();
	}

	/*
	 *  Converter
	 */

	public function actionConverterU() {
		$tasklist = CBeanstalk::model()->tasklist();
		if (!CThread::$useForks) {
			echo PHP_EOL . "You do not have the minimum system requirements to work in async mode!!!";
			if (!CShell::$hasForkSupport) {
				echo PHP_EOL . "You don't have pcntl or posix extensions installed or either not CLI SAPI environment!";
			}
			if (!CShell::$hasLibevent) {
				echo PHP_EOL . "You don't have libevent extension installed!";
			}
			echo PHP_EOL;
		}

// ----------------------------------------------
		$threads = 8;
		$jobs = range(1, 30);
		$jobs_num = count($jobs);

		echo PHP_EOL . "Example with pool of threads ($threads) and pool of jobs ($jobs_num)" . PHP_EOL;

		$pool = new CThreadPool('ConvertThreadEvents', $threads);
		$run = true;
		$started = array();

		while ($run) {
			if ($pool->hasWaiting()) {
				$job = $tasklist->reserveFromTube('convert_u', 25);
				if ($job) {
					if (!$threadId = $pool->run($job)) {
						throw new Exception('Pool slots error');
					}
					$started[$threadId] = $job;
				}
			}
			if ($results = $pool->wait($failed)) {
				foreach ($results as $threadId => $result) {

					$tasklist->deleteA($started[$threadId]->getId());
					unset($started[$threadId]);
					echo 'result: ' . $result . PHP_EOL;
				}
			}
			if ($failed) {
// Error handling here
// processing is not successful if thread dies
// when worked or working timeout exceeded
				foreach ($failed as $threadId) {
					$tasklist->releaseA($started[$threadId]->getId());

					echo 'error: ' . $started[$threadId] . PHP_EOL;
					unset($started[$threadId]);
				}
			}
		}

		$pool->cleanup();
	}

}

class ConvertThreadEvents extends CThread {
	const EV_PROCESS = 'process';

	protected $timeoutWork = 0;
	/* Encode */

	protected function process() {
		$job = $this->getParam(0);
		echo 'Got job ';
		var_dump($job);
		$job_id = @$job->getId();
		if ($job_id) {
			$job_data = json_decode($job->getData());
			$path = '';
			$conv_cp = '/mnt/remote/' . $job_data->ip . '/' . $path . $job_data->fname;
			echo $conv_cp;
			$conv_path = '/mnt/convert/' . $job_id . '/';
			$conv_src = '/mnt/convert/' . $job_id . '/' . $job_data->fname;
			if (!isset($job_data->step)) {
				echo "Trying to copy ";
				if (isset($job_data->fpath))
					$path = $job_data->fpath;
				shell_exec('mkdir ' . $conv_path);
				shell_exec('rsync ' . $conv_cp . ' ' . $conv_src);
//shell_exec("scp $job_data->ip:/var/tmp/uploads/$job_data->fname /mnt/userdata/$job_data->fname");
			}

			if (file_exists($conv_src)) {
				$fsize = filesize($conv_src);
				if ($fsize <> $job_data->fsize) {
					echo "size is bad";
//$tasklist->release($job, 50, 30);
					die(-1);
				}
			} else {
				echo "not exists $conv_src ";
//$tasklist->release($job, 50, 30);
				die(-1);
			}

			$conv_dest = '/mnt/convert/' . $job_id . '/result';
			$log_dest = '/mnt/convert/' . $job_id . '/';
			echo "Convert start";
			$tasklist = CBeanstalk::model()->tasklist();

			@shell_exec('/usr/scripts/convert/v/' . $job_data->preset . '.sh ' . $conv_src . ' ' . $conv_dest . ' ' . $log_dest);
			if (file_exists($conv_dest)) {
				echo "Converted";
				$size = filesize($conv_dest);
				if ($size > 0) {
					echo "put task";
					$data = array();
					$data['fid'] = $job_data->fid;
					$data['ip'] = Yii::app()->params['mycloud']['local_ip'];
					$data['user_id'] = $job_data->user_id;
					$data['stype'] = 4;
					$data['preset'] = $job_data->preset;
					$data['fsize'] = $fsize;
					$data['fname'] = '/' . $job_id . '/result';
					$data['task_id'] = $job_id;
					$tasklist->putInTube('download_t', json_encode($data), 50, 0, 2000);
					return 1;
				} else {
					echo "bad result size";
//$tasklist->release($job);
					return 0;
				}
			} else {
				echo "Convert failed";
				return 0;
//$tasklist->release($job);
			}
		}
		return 0;
	}

}