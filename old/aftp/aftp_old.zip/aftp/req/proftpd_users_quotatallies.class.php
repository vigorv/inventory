<?
debug("%1%���������� req/proftpd_users_quotatallies.class.php");

include_once PATH_REPOSIT."/template.class.php";
class proftpd_users_quotatallies extends template
{
    function proftpd_users_quotatallies()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='proftpd users';
    	 //$this->SETTINGS['pager_type']=2;
    	$vars=array();
 	    $configs=array();
        $configs["get_arrays"]['proftpd.users']=array("login");
        $this->PARAMS["showparams"]["parent"]=array(
                                                'table'=>'proftpd.users'
                                                ,'name'=>'������������'
                                                ,'column'=>'login'
                                                ,'where'=>'id=%p%'
                                                ,"link"=>'proftpd_users.php?id=%p%&act=show'
                                              );

	 		$var=array();
	 		$var["name"]="id";$var["string"]="id";
	 		$var["is_edit"]=0;
	 		$var["show"]["type"]="%id%";
	 		$var["is_save"]=0;
	 	$vars[$var["name"]]=$var;

	 	    $var=array();
	 		$var["name"]="parent";$var["string"]="������������";
            $var["edit"]["type"]="list";
            $var["edit"]["value_list"]='proftpd.users';
            $var["show"]["type"]='proftpd.users';
       $vars[$var["name"]]=$var;
	 	
	 	    $var=array();
	 		$var["name"]="login";$var["string"]="������������";
	 	$vars[$var["name"]]=$var;

	 	     $var=array();
	 		$var["name"]="bytes_in_used";$var["string"]="���� �������������";
	 	$vars[$var["name"]]=$var;

	 	$vars[$var["name"]]=$var;
        $configs["table_name"]='proftpd.quotatallies';

	 	$this->init($vars,$configs);
    }

}
?>
