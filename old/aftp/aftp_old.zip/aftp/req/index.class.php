<?
debug("%1%���������� req/index.class.php");

include_once PATH_REPOSIT."/template.class.php";
//include_once(PATH_API.'/films.class.php');

class index extends template
{
    function index()
    {
        global $SETTINGS;
        parent::template();
        $this->PARAMS['part_name']='�������';
        include $SETTINGS["PATH_INC"]."/top.html";
        /*$flm=new films();
        $flm->get_index_data();
        $this->PARAMS["top3_show"]=$flm->PARAMS["top3_show"];
        $this->PARAMS["new3_show"]=$flm->PARAMS["new3_show"];
        $this->PARAMS["new10_show"]=$flm->PARAMS["new10_show"];
        $this->PARAMS["top10_show"]=$flm->PARAMS["top10_show"];
*/
        include $SETTINGS["PATH_INC"]."/index.html";
        include $SETTINGS["PATH_INC"]."/bottom.html";

    }
}
?>
