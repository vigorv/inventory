<?php
/**
 * Created by JetBrains PhpStorm.
 * User: snow
 * Date: 08.06.12
 * Time: 11:30
 * To change this template use File | Settings | File Templates.
 */
class UniverseController extends Controller
{

    public function actionError()
    {
        $error = Yii::app()->errorHandler->error;
        if ($error) {
            if (Yii::app()->request->isAjaxRequest)
                echo $error['message'];
            else
                var_dump($error);
//$this->render('error', $error);
        }
    }
}