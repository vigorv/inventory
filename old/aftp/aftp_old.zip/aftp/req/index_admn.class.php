<?
debug("%1%���������� req/index.class.php");

include_once PATH_REPOSIT."/template.class.php";
class index extends template
{
    function index()
    {
        global $SETTINGS;
        parent::template();
        include $SETTINGS["PATH_INC"]."/admin/top.html";
        //include $SETTINGS["PATH_INC"]."/admin/index.html";
        //$this->convert_base();
        include $SETTINGS["PATH_INC"]."/admin/bottom.html";
    }

    //��������� �� ������ ���� � �����.����� 1 ������� ������� ������
    function convert_base_faze1()
    {
        $sql=new SQL('localhost','root','123');
        $sql->sql_execute('select * from media_01_22.films where 1');
        while($row=$sql->sql_fetch_assoc())
        {
            $id=$row['id'];
            $name=addslashes($row['name']);
            $name_eng=addslashes($row['origname']);
            $info=addslashes($row['info']);
            $year=$row['year'];
            $popular=($row['popular']==1)?'Y':'N';
            if(trim($name)!='')$n=trim($name);
            if(trim($name_eng)!='')$n=trim($name_eng);
            $dir=transliteratetodir($n);
            $dir=str_replace('_-_','-',$dir);
            $dir=str_replace('-_','-',$dir);
            $dir=str_replace('_-','-',$dir);
            $dir=str_replace('__','_',$dir);
            $i=2;
            $dir1=$dir;

            while(is_dir('c:/4/'.$dir1))
            {
                $dir1=$dir."_".$i++;
            };
            mkdir('c:/4/'.$dir1);
            $sql->sql_execute("insert into media_new.films(name,name_eng,info,year,ishit,dir,id_old) VALUE(
        '".$name."',
        '".$name_eng."',
        '".$info."',
        '".$year."',
        '".$popular."',
        '".$dir1."',
        '".$id."'
        )");
            $sql->res_pop();
            $sql->sql_execute("select LAST_INSERT_ID()");
            $id_new=$sql->sql_result(0,0);
            $sql->res_pop();
            $rrr=array(
            'actor'=>'film_acters',
            'reg'=>'film_reg',
            'janr'=>'film_genres',
            'country'=>'film_country',
            'company'=>'film_publishers',
            'emotion'=>'film_emotions',
            'theme'=>'film_themes'
            );
            foreach ($rrr as $k=>$table)
            {
                $outtar=explode(',',$row[$k]);
                $outttar=array();
                foreach ($outtar as $v)
                {
                    if((int)$v>0)
                    {$curar=array();
                    $curar=$v;
                    $outttar[]=$curar;
                    }
                }
                $r=$outttar;
                foreach($r as $v)
                {
                    $sql->sql_execute("insert into media_new.".$table." (parent, child) values ('".$id_new."','".$v."')");
                    $sql->res_pop();
                }
            }
        }
        /*sort($dirs);
        reset($dirs);
        echo "<pre>";print_r($dirs);*/
        $sql->sql_close();
    }

    //���� 2 ������������ �������
    function convert_base_faze2()
    {
        $dir1=$this->SETTINGS['SERVER_IMG_URL']."/poster2";
        $dir2=$this->SETTINGS['SERVER_IMG_URL']."/poster";
        $sql=new SQL('localhost','root','123');
        //echo $dir1.var_dump(is_dir($dir1));
        $sql->sql_execute('select id,id_old from media_new.films where 1');
        while($row=$sql->sql_fetch_assoc())
        {
            $id_new=$row['id'];
            $id_old=$row['id_old'];
            if(is_file($dir1."/".$id_old.".jpg"))rename($dir1."/".$id_old.".jpg",$dir2."/".$id_new.".jpg");

        }
    }

    //���� 3 ������� �.������.
    function convert_base_faze3()
    {
        $sql=new SQL('localhost','root','123');
        $sql->sql_execute('select id,id_old,dir from media_new.films');
        //("SELECT SEC_TO_TIME(sum(TIME_TO_SEC(timelimit))) FROM media_01_22.files WHERE 1 group by parent");
        while($row=$sql->sql_fetch_assoc())
        {
            $parent=$row['id'];
            $id_old=$row['id_old'];
            $film_dir=$row['dir'];

            $sql->sql_execute("SELECT sound,razr,zvezda,video,dateadd,SEC_TO_TIME(sum(TIME_TO_SEC(timelimit)))as time FROM media_01_22.files where parent=".$id_old." group by parent");
            while($row2=$sql->sql_fetch_assoc())
            {
                $translate=$row2['sound'];
                $video_q=$row2['video'];
                $dateadd=$row2['dateadd'];
                $timelimit=$row2['time'];
                $razr=$row2['razr'];
                $zvezda=$row2['zvezda'];
            }
            //$sql->res_pop();

            $sql->sql_execute("insert into media_new.film_records(
        parent,translate,video_type,video_quality,razr,zvezda,lenght,dateadd,dir
        ) VALUE(
        '".$parent."',
        '".$translate."',
        '1',
        '".$video_q."',
        '".$razr."',
        '".$zvezda."',
        '".$timelimit."',
        '".$dateadd."',
        'DivX'
        )");
            $sql->res_pop();

            $sql->sql_execute("select LAST_INSERT_ID()");
            $id_record=$sql->sql_result(0,0);
            $sql->res_pop();

            $sql->sql_execute("insert into media_new.film_record_servers(parent,child) VALUE('".$id_record."','1')");
            $sql->res_pop();
            $sql->sql_execute("insert into media_new.film_record_language(parent,child) VALUE('".$id_record."','1')");
            $sql->res_pop();

            $sql->sql_execute("SELECT name,size,id FROM media_01_22.files where parent=".$id_old);
            $i=1;
            while($row2=$sql->sql_fetch_assoc())
            {
                $name=$row2['name'];
                $size=$row2['size'];
                $id_old=$row2['id'];
                $sql->sql_execute("insert into media_new.film_record_files(
            parent,name,size,dir,id_old
            ) VALUE(
            '".$id_record."',
            '".$name."',
            '".$size."',
            '".$i."',
            '".$id_old."'
            )");
                $sql->res_pop();
                $i++;
            }
            //$sql->res_pop();
            /*        $sql->res_pop();
            $sql->res_pop();
            */
        }
    }
    //���� 4 ������� �������
    function convert_base_faze4()
    {
        $sql=new SQL('localhost','root','123');
        $sql->sql_execute('select id,name,info from media_01_22.actor');
        while($row=$sql->sql_fetch_assoc())
        {
            $id_old=$row['id'];
            $name=addslashes($row['name']);
            $info1=$name;
            $names=explode(' ',$name);
            if(count($names)==2)
            {
                $firstname=$names[0];
                $name=$names[1];
            }
            else
            {
                $firstname=$name;
                $name='';
            }

            $info=addslashes($row['info']);
            $info1.=" ".$info;
            $names_eng=explode(' ',$info);

            if(count($names_eng)==2)
            {
                $firstname_eng=$names_eng[0];
                $name_eng=$names_eng[1];
            }
            else
            {
                $firstname_eng=$info;
                $name_eng='';
            }
            echo "insert into media_new.persons (firstname,name,firstname_eng,name_eng,info,id_old_a) VALUES('".$firstname."','".$name."','".$firstname_eng."','".$name_eng."','".$info1."','".$id_old."')<br>";
            $sql->sql_execute("insert into media_new.persons (firstname,name,firstname_eng,name_eng,info,id_old_a)
            VALUES(
            '".$firstname."',
            '".$name."',
            '".$firstname_eng."',
            '".$name_eng."',
            '".$info1."',
            '".$id_old."'
            )");
            $sql->res_pop();
            $sql->sql_execute("select LAST_INSERT_ID()");
            $id_record=$sql->sql_result(0,0);
            $sql->res_pop();

            $sql->sql_execute("insert into media_new.person_profs(parent,child) VALUE('".$id_record."','3')");
            $sql->res_pop();
        }
    }
    //���� 5 ���������
    function convert_base_faze5()
    {
        $sql=new SQL('localhost','root','123');
        $sql->sql_execute('select id,name,info from media_01_22.reg');
        while($row=$sql->sql_fetch_assoc())
        {
            $id_old=$row['id'];
            $name=addslashes($row['name']);
            $info1=$name;
            $names=explode(' ',$name);
            if(count($names)==2)
            {
                $firstname=$names[0];
                $name=$names[1];
            }
            else
            {
                $firstname=$name;
                $name='';
            }

            $info=addslashes($row['info']);
            $info1.=" ".$info;
            $names_eng=explode(' ',$info);

            if(count($names_eng)==2)
            {
                $firstname_eng=$names_eng[0];
                $name_eng=$names_eng[1];
            }
            else
            {
                $firstname_eng=$info;
                $name_eng='';
            }
            $sql->sql_execute("select id,name,info from media_new.persons where info='".$info1."'");
            if($sql->sql_num_rows()==0)
            {
                $sql->sql_execute("insert into media_new.persons (firstname,name,firstname_eng,name_eng,info,id_old_r)
            VALUES(
            '".$firstname."',
            '".$name."',
            '".$firstname_eng."',
            '".$name_eng."',
            '".$info1."',
            '".$id_old."'
            )");
                $sql->res_pop();
                $sql->sql_execute("select LAST_INSERT_ID()");
                $id_record=$sql->sql_result(0,0);
                $sql->res_pop();
            }
            else
            {
                $row2=$sql->sql_fetch_assoc();
                $id_record=$row2['id'];
                $sql->sql_execute("update media_new.persons set id_old_r=".$id_old." where id=".$id_record);
                $sql->res_pop();
            }
            $sql->res_pop();
            $sql->sql_execute("insert into media_new.person_profs(parent,child) VALUE('".$id_record."','1')");
            $sql->res_pop();
        }
    }
    //���� 6 ������� ������� �������
    function convert_base_faze6()
    {
        $sql=new SQL('localhost','root','123');
        $acters=array();
        $sql->sql_execute('select id,id_old_a from media_new.persons');
        while($row=$sql->sql_fetch_assoc())
        {
            $acters[$row['id_old_a']]=$row['id'];
        }
        $sql->sql_execute('select * from media_new.film_acters');
        while($row=$sql->sql_fetch_assoc())
        {
            $id=$row['id'];
            $id_act_old=$row['child'];
            $sql->sql_execute("update media_new.film_acters set child='".$acters[$id_act_old]."' where id=".$id);
            $sql->res_pop();
        }
        
    }

   //���� 7 ������� ���������� �������
    function convert_base_faze7()
    {
        $sql=new SQL('localhost','root','123');
        $acters=array();
        $sql->sql_execute('select id,id_old_r from media_new.persons');
        while($row=$sql->sql_fetch_assoc())
        {
            $acters[$row['id_old_r']]=$row['id'];
        }
        $sql->sql_execute('select * from media_new.film_reg');
        while($row=$sql->sql_fetch_assoc())
        {
            $id=$row['id'];
            $id_act_old=$row['child'];
            $sql->sql_execute("update media_new.film_reg set child='".$acters[$id_act_old]."' where id=".$id);
            $sql->res_pop();
        }
        
    }
    //���� 8 �������� ��������� � ������� ������
    function convert_base()
    {
        $dir_old="/mnt/raid/media/";
        $dir_new="/mnt/raid/media_new/";
        $sql=new mySQL();
        $sql->sql_execute("SELECT CONCAT_WS( '/', f.dir, r.dir, fi.dir )as makedir ,CONCAT(f.id_old,'_',fi.id_old,'.avi' ) as old_file_name, fi.name as new_name
            FROM films AS f
            INNER JOIN (
            film_records AS r
            INNER JOIN film_record_files AS fi ON ( r.id = fi.parent ) 
            ) ON ( r.parent = f.id ) 
            LIMIT 0
        ");
        while($row=$sql->sql_fetch_assoc())
        {
            $new_dir=$row['makedir'];
            $old_file_name=$row['old_file_name'];
            $new_name=$row['new_name'];
            echo "mkdir(".$dir_new.$new_dir.",0777,TRUE)"."<br>";
            echo "rename(".$dir_old.$old_file_name.",".$dir_new.$new_dir."/".$new_name.")"."<br>";
            //mkdir($dir_new.$new_dir,0777,TRUE);
            //rename($dir_old.$old_file_name,$dir_new.$new_dir."/".$new_name);

        }
    }
}
?>