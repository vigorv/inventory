<?
include "config.inc.php";
include_once(PATH_API.'/proftpd_users.class.php');
$obj= new proftpd_users();
$obj->action();
debug_echo();
?>
