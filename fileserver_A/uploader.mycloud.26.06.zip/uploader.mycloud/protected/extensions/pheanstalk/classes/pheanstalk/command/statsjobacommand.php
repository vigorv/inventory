<?php

/**
 * The 'stats-job' command.
 * Gives statistical information about the specified job if it exists.
 *
 * @author Paul Annesley
 * @package Pheanstalk
 * @licence http://www.opensource.org/licenses/mit-license.php
 */
class Pheanstalk_Command_StatsJobACommand
	extends Pheanstalk_Command_AbstractCommand
{
	private $_jobId;

	/**
	 * @param Pheanstalk_Job or int $job
	 */
	public function __construct($job_id)
	{
		$this->_jobId = $job_id;
	}

	/* (non-phpdoc)
	 * @see Pheanstalk_Command::getCommandLine()
	 */
	public function getCommandLine()
	{
		return sprintf('stats-job %d', $this->_jobId);
	}

	/* (non-phpdoc)
	 * @see Pheanstalk_Command::getResponseParser()
	 */
	public function getResponseParser()
	{
		return new Pheanstalk_YamlResponseParserA(
			Pheanstalk_YamlResponseParserA::MODE_DICT
		);
	}
}
