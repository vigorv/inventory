<?
include "config.inc.php";
include_once(PATH_API.'/index.class.php');
$obj= new index();
debug_echo();
?>


