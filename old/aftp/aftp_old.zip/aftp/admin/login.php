<?
include "config.inc.php";
//include_once(PATH_API.'/admn.php');

//$obj=new admn();
$admn->action_admn();
debug_echo();
?>