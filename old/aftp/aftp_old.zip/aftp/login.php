<?
include "config.inc.php";
include_once(PATH_REPOSIT.'/user.class.php');
//$user= new user();
$user->action_user();
debug_echo();
?>


